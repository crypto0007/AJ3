import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Demo extends HttpServlet
{
	String pass="admin";
	String user="admin";

	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
	{
		response.setContentType("text/html");

		String pa=req.getParameter("name");

	}

}

