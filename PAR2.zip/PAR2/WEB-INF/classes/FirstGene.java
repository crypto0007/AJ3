import java.io.*;
import javax.servlet.*;
import java.util.*;
public class FirstGene extends GenericServlet
{
	public void service(ServletRequest req,ServletResponse res)throws IOException,ServletException
	{
	res.setContentType("text/html");
	PrintWriter out=res.getWriter();
	Date d=new Date();
	out.print("<html><body>");
	out.print("<b>hello</b>");
	out.print("<h1>"+d.toString()+"</h1>");
	out.print("</body></html>");
	}
}
