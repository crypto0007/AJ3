import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Demo1 extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException
  {

	  ServletConfig conf = getServletConfig();
	  response.setContentType("text/html");
	  PrintWriter out = response.getWriter();
	  String name = conf.getInitParameter("colorname");
	  String u_name=request.getParameter("u_name");
	  out.print(u_name);
	  //out.print("<html><body>");
	  //out.print("<h1>HELLO</h1>");
	  //out.print("<h1 style='background-color : "+name+"'>"+"</h1>");
	  //out.print("</body></html>");
  }


}