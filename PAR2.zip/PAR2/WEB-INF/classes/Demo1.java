import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Demo2 extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException
  {

	  ServletConfig config=getServletConfig();
	  response.setContentType("text/html");
	  PrintWriter out = response.getWriter();
	  String name = config.getInitParameter("username");
	  String pass=request.getParameter("password");
	  out.print("KHN");
	  out.print("PATEL");
	 out.print("NAME IS:"+name);
	 out.print("NAME IS:"+pass);
	 out.print("<html><body>");
	 out.print("</body></html>");
  }


}