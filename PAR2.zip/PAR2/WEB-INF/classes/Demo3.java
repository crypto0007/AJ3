import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Demo3 extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException
  {

	  ServletConfig config=getServletConfig();
	  response.setContentType("text/html");
	  PrintWriter out = response.getWriter();
	  String name = config.getInitParameter("user_Name");
	  String pass=config.getInitParameter("psw");
	  String u_name=request.getParameter("u_name");
	  String pass1=request.getParameter("pass");

	  if(pass.equals(pass1) && name.equals(u_name))
	  {

		  out.print("KHANTIL");
		  response.sendRedirect("Welcome.html");

	  }
	  else
	  {
		  response.sendRedirect("Login.html");
		  out.print("SORRY USER NAME OR PASSWORD IS WRONG");
	  }
	 out.print("<html><body>");
	 out.print("</body></html>");
  }


}