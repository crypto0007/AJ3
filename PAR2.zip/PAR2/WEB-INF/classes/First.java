import java.io.*;
import javax.servlet.*;
public class First implements Servlet
{
		ServletConfig config=null;
		public void init(ServletConfig config)
		{
			this.config=config;
			System.out.println("servlet is initialized");
		}
		public void service(ServletRequest req,ServletResponse res)throws ServletException,IOException
		{
				res.setContentType("text/html");
				PrintWriter out=res.getWriter();
				out.print("<html><body><h1>HELLO WORLD</h1></body></html>");


		}
		public void destroy()
		{
		}
		public ServletConfig getServletConfig(){return config;}
		public String getServletInfo(){return "copyright 2007-1010";}
}