import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Demo2 extends HttpServlet
{
	public void doPost(HttpServletRequest request,HttpServletResponse response)throws ServletException, IOException
  {

	  ServletContext context=getServletContext();
	  response.setContentType("text/html");
	  PrintWriter out = response.getWriter();
	  String name = context.getInitParameter("username");
	  String pass=context.getInitParameter("password");
	  String u_name=request.getParameter("u_name");
	  String pass1=request.getParameter("pass");
	  if(pass.equals(pass1) && name.equals(u_name))
	  {

		  out.print("KHANTIL");
		  response.sendRedirect("Welcome.html");

	  }
	  else
	  {
		  response.sendRedirect("Login.html");
		  out.print("SORRY USER NAME OR PASSWORD IS WRONG");
	  }
	 out.print("<html><body>");
	 out.print("</body></html>");
  }


}